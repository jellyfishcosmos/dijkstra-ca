package london;

public class Location {
    public String name;
    int posX;
    int posY;
    int id;

    public Location(String name, int posX, int posY, int id) {
        this.name = name;
        this.posX = posX;
        this.posY = posY;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public String getName() {
        return name;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

}
