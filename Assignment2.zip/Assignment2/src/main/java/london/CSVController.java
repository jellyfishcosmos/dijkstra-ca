package london;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CSVController{
    ArrayList<Node<Location>> stations = new ArrayList<Node<Location>>();


    /**
     * Loads everything from CSV into files
     */
    public void load() {
        loadStations();
       // connections();
        loadLines();
        System.out.println(stations.get(1).getData());
    }

//
//    public void connections() {
//        stations.get(34).connectToNodeUndirected(stations.get(0), calculateDistance(stations.get(34), stations.get(0)));
//        stations.get(34).connectToNodeUndirected(stations.get(33), calculateDistance(stations.get(34), stations.get(33)));}
    /**
     * loads from stations.csv into arrayList
     */
    private void loadStations() {
        //String path = "src/london/station.csv";
        String path = "C:\\Users\\Sam Taylor\\OneDrive - Waterford Institute of Technology\\semester 4\\Assignment2\\src\\main\\java\\london\\station.csv";
        String line = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                Location station;
                station = new Location(values[0], Integer.parseInt(values[1]), Integer.parseInt(values[2]), Integer.parseInt(values[3]));
                Node<Location> Node = new Node(station);
                stations.add(Node);


            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Node <Location> getNodeById(int id){
        for (int i =0; i< stations.size(); i++) {
            if (stations.get(i).getData().id == id){
                return stations.get(i);
            }
        }return null;

    }
    private void loadLines() {
        //String path = "src/london/lines.csv";
        String path = "C:\\Users\\Sam Taylor\\OneDrive - Waterford Institute of Technology\\semester 4\\Assignment2\\src\\main\\java\\london\\lines.csv";
        String line = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                int sourceId = Integer.parseInt(values[0]);
                int destId = Integer.parseInt(values[1]);
                Node<Location> sourceNode = getNodeById(sourceId);
                Node<Location> destNode = getNodeById(destId);
                if(sourceNode != null && destNode != null)
                    sourceNode.connectToNodeUndirected(destNode,calculateDistance(sourceNode,destNode));

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public ArrayList<Node<Location>> getStations() {
        return stations;
    }

    /**
     * Distance formula from coordinate geometry
     *
     * @param first a point on the map
     * @param last  another point on the map
     * @return
     */
    public int calculateDistance(Node<Location> first, Node<Location> last) {
        double xSquared = first.getData().getPosX() + last.getData().getPosX();
        xSquared = xSquared * xSquared;
        double ySquared = first.getData().getPosY() + last.getData().getPosY();
        ySquared = ySquared * ySquared;
        return (int) Math.sqrt(xSquared + ySquared);
    }


}