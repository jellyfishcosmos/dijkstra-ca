//package london;
//
//public class CodeDump {
//}
//    ArrayList<Node<Location>> landMarks = new ArrayList<Node<Location>>();
//    ArrayList<String> landMarkNames = new ArrayList<>();
//    public ArrayList<Node<Location>> getLandMarks() {
//        return landMarks;
//    }
//                        <Button layoutX="287.0" layoutY="752.0" mnemonicParsing="false" onAction="#clearLines" text="Clear all lines" />
//    public ArrayList<String> getLandMarkNames() {
//        return landMarkNames;
//    }
//    /**
//     * Builds landmarksName arrayList for using entering into the choiceBox in controller
//     */
//    private void buildArrayListOfNames() {
//        for (int i = 0; i < landMarks.size(); i++) {
//            landMarkNames.add(landMarks.get(i).getData().getName());
//        }
//    }