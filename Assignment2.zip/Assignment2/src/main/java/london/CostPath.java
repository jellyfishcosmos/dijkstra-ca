package london;

import java.util.ArrayList;

public class CostPath {
    public int pathCost = 0;
    public ArrayList<Node<Location>> pathList = new ArrayList<>();
}