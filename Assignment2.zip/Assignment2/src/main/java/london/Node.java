package london;

import java.util.ArrayList;
import java.util.List;

public class Node<T>{
    private T data;
    private List<Link> adjList = new ArrayList<>();
    private int nodeValue = Integer.MAX_VALUE;


    public Node(T data) {
        this.data = data;
    }

//    public void connectToNodeDirected(Node<Location> destNode, int cost) {
//        adjList.add(new Link((Node<london.Location>) destNode, cost));
//    }

    public void connectToNodeUndirected(Node<Location> destNode, int cost) {
        adjList.add(new Link((Node<london.Location>) destNode, cost));
        destNode.adjList.add(new Link((Node<london.Location>) this, cost));
    }

    public void setNodeValue(int nodeValue) {
        this.nodeValue = nodeValue;
    }

    public int getNodeValue() {
        return nodeValue;
    }

    public T getData() {
        return data;
    }

    public List<Link> getAdjList() {
        return adjList;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setAdjList(List<Link> adjList) {
        this.adjList = adjList;
    }

}
