package london;

public class Link {
    public Node<Location> destNode; //Could also store source node if required
    public int cost; //Other link attributes could be similarly stored

    public void setDestNode(Node<Location> destNode) {
        this.destNode = destNode;
    }

    public Node<Location> getDestNode() {
        return destNode;
    }

    public Link(Node<Location> destNode, int cost) {
        this.destNode = destNode;
        this.cost = cost;
    }
}

