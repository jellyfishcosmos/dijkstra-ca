module com.example.assignment2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens london to javafx.fxml;
    exports london;
}